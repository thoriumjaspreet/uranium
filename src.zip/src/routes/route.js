


const express = require('express');
const router = express.Router();
 const userModel= require("../models/userModel.js")
const userController= require("../controllers/userController")

const productController = require("../controllers/productcontroller")
const orderController= require("../controllers/ordercontroller")
const commonMiddlewares= require("../middlewares/commonMiddlewares")
router.get("/test-me", function (req, res) {
    res.send("My first ever api!")
})

//router.post("/createUser",Middleware.middleware1, userController.createUser  )
router.post("/createUser",commonMiddlewares.isFreeAppUserMiddleware,userController.createUser)

router.get("/getUsersData", userController.getUsersData)
router.post("/productSchema",productController.productSchema)
//router.post("/createOrder", Middleware.middleware1,orderController.createOrder)
router.post("/createOrder",commonMiddlewares.isFreeAppUserMiddleware,orderController.createOrder  )
router.get("/getOrderData", orderController.getOrderData)



module.exports = router;