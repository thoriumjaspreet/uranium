const batchesModel = require("../models/batchesModel")
const developersModel= require("../models/developersModel")

const createDeveloper= async function (req, res) {
    let developer= req.body
    let developerCreated = await developersModel.create(developer)
    res.send({data: developerCreated})
}

module.exports.createDeveloper= createDeveloper








// const getBooksData= async function (req, res) {
//     let books = await bookModel.find()
//     res.send({data: books})
// }

// const getBooksWithAuthorDetails = async function (req, res) {
//     let specificBook = await bookModel.find().populate('author_id')
//     res.send({data: specificBook})

///}

