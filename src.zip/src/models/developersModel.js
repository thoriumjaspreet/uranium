const mongoose = require('mongoose');

const developersSchema = new mongoose.Schema( {
    
        
                name:String,
                gender:String,
                percentage:Number,
    gender:
        {
            type:String,
            enum:   ["Male","Female" ]
            
        }   

}, { timestamps: true });

module.exports = mongoose.model('developer', developersSchema)
